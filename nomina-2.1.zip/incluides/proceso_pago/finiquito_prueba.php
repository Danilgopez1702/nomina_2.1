<?php
$entrada = "2020";
$salida = "2022";

$total = $salida - $entrada;

echo $total;
?>